
function validateForm() {

    let name = document.getElementById("full_name").value;
    let username = document.getElementById("username").value;
    let email = document.getElementById("email").value;
    let mobile = document.getElementById("mobile").value;
    let password = document.getElementById("password").value;
    let confirmPassword = document.getElementById("confirm_password").value;
    let role = document.getElementById("role").value;
    let city = document.getElementById("city").value;
    let terms = document.querySelector('input[name="terms"]').checked;

    if (name.trim() === "") {
        alert("Please enter your name.");
        return false;
    }

    if (username.length < 4) {
        alert("Username must have at least 4 characters.");
        return false;
    }

    if (!email.includes("@")) {
        alert("Please enter a valid email.");
        return false;
    }

    if (!/^[6-9][0-9]{9}$/.test(mobile)) {
        alert("Please enter a valid 10-digit mobile number.");
        return false;
    }

    if (password.length < 6) {
        alert("Password must have at least 6 characters.");
        return false;
    }

    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return false;
    }

    if (role === "") {
        alert("Please select an option.");
        return false;
    }

    if (city.trim() === "") {
        alert("Please enter your city.");
        return false;
    }

    if (!terms) {
        alert("Please accept the Terms & Conditions.");
        return false;
    }

    alert("Registration successful!");

    return true;
}


// HopeLink Login Validation

function validateLogin() {

    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    if (email.trim() === "") {
        alert("Please enter your email.");
        return false;
    }

    if (!email.includes("@")) {
        alert("Please enter a valid email.");
        return false;
    }

    if (password === "") {
        alert("Please enter your password.");
        return false;
    }

    if (password.length < 6) {
        alert("Password must have at least 6 characters.");
        return false;
    }

    alert("Login successful!");

    return true;
}

